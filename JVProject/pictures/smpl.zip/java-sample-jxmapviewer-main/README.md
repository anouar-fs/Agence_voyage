# java-sample-jxmapviewer

![2021-12-03_225051](https://user-images.githubusercontent.com/58245926/144711314-bd4674f9-b6f9-4614-9d33-446367c912ef.png)

![2022-07-30_003532](https://user-images.githubusercontent.com/58245926/181814359-c22d6476-fe3b-4d25-bc37-8f8a9e197f0b.png)
